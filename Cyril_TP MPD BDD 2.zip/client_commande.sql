-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 10 oct. 2023 à 14:01
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `client_commande`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `id_Categorie` int NOT NULL AUTO_INCREMENT,
  `Code_Categorie` int DEFAULT NULL,
  `Designation_Categorie` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_Categorie`, `Code_Categorie`, `Designation_Categorie`) VALUES
(1, 4520, 'Sport'),
(2, 4521, 'Vetement homme'),
(3, 4522, 'Vetement femme'),
(4, 4523, 'Vetement enfant'),
(5, 4524, 'Boisson'),
(6, 4525, 'Alimentaire perissable'),
(7, 4526, 'alimentaire non-perissable'),
(8, 4527, 'Papeterie'),
(9, 4528, 'Outillage'),
(10, 4529, 'Jardinage');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id_Client` int NOT NULL AUTO_INCREMENT,
  `Code_Client` int DEFAULT NULL,
  `Nom_Client` varchar(50) DEFAULT NULL,
  `Adresse_Client` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Client`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_Client`, `Code_Client`, `Nom_Client`, `Adresse_Client`) VALUES
(1, 1220, 'Pigeon', 'Orléans'),
(2, 1221, 'Saisai', 'Saran'),
(3, 1222, 'Poulard', 'Olivet'),
(4, 1223, 'Djameli', 'Orléans'),
(5, 1224, 'Laboucher', 'Artenay'),
(6, 1225, 'Vacher', 'Toulouse'),
(7, 1226, 'Rocher', 'Lyon'),
(8, 1227, 'Bidulle', 'Marseille'),
(9, 1228, 'Ahbon', 'Paris'),
(10, 1229, 'Tulipe', 'Metz');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id_Commande` int NOT NULL AUTO_INCREMENT,
  `Numero_de_Commande` int DEFAULT NULL,
  `Dates` date DEFAULT NULL,
  `id_Four` int NOT NULL,
  `id_client` int NOT NULL,
  PRIMARY KEY (`id_Commande`),
  KEY `id_Four` (`id_Four`),
  KEY `id_client` (`id_client`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_Commande`, `Numero_de_Commande`, `Dates`, `id_Four`, `id_client`) VALUES
(11, 2, '2023-10-01', 11, 1),
(12, 3, '2023-09-06', 13, 7),
(13, 4, '2023-09-08', 12, 3),
(14, 5, '2023-09-11', 13, 9),
(15, 6, '2023-10-05', 11, 6);

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

DROP TABLE IF EXISTS `fournisseur`;
CREATE TABLE IF NOT EXISTS `fournisseur` (
  `id_Four` int NOT NULL AUTO_INCREMENT,
  `Code_Four` int DEFAULT NULL,
  `Nom_Four` varchar(50) DEFAULT NULL,
  `Adresse_Four` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Four`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `fournisseur`
--

INSERT INTO `fournisseur` (`id_Four`, `Code_Four`, `Nom_Four`, `Adresse_Four`) VALUES
(11, 5001, 'Addidas', 'Paris'),
(12, 5002, 'Danone', 'Lorient'),
(13, 5003, 'Asics', 'Strasbourg');

-- --------------------------------------------------------

--
-- Structure de la table `porter_sur`
--

DROP TABLE IF EXISTS `porter_sur`;
CREATE TABLE IF NOT EXISTS `porter_sur` (
  `id_Commande` int NOT NULL,
  `id_Produit` int NOT NULL,
  `Quantité` int DEFAULT NULL,
  PRIMARY KEY (`id_Commande`,`id_Produit`),
  KEY `id_Commande` (`id_Commande`),
  KEY `id_Produit` (`id_Produit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `porter_sur`
--

INSERT INTO `porter_sur` (`id_Commande`, `id_Produit`, `Quantité`) VALUES
(11, 11, 25),
(12, 13, 26),
(15, 14, 45);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `id_Produit` int NOT NULL AUTO_INCREMENT,
  `Reference_produit` varchar(50) DEFAULT NULL,
  `Designation_produit` varchar(50) DEFAULT NULL,
  `Prix` double DEFAULT NULL,
  `id_Categorie` int NOT NULL,
  PRIMARY KEY (`id_Produit`),
  KEY `id_Categorie` (`id_Categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id_Produit`, `Reference_produit`, `Designation_produit`, `Prix`, `id_Categorie`) VALUES
(11, '800', 'Ballon de foot', 10.2, 1),
(12, '801', 'Veste homme', 30.85, 2),
(13, '802', 'Veste femme', 32.74, 3),
(14, '803', 'Robe enfant', 12.45, 4),
(15, '804', 'Bière', 1, 5);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `client` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_Client`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `four` FOREIGN KEY (`id_Four`) REFERENCES `fournisseur` (`id_Four`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `porter_sur`
--
ALTER TABLE `porter_sur`
  ADD CONSTRAINT `commande` FOREIGN KEY (`id_Commande`) REFERENCES `commande` (`id_Commande`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `produit` FOREIGN KEY (`id_Produit`) REFERENCES `produit` (`id_Produit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `produit`
--
ALTER TABLE `produit`
  ADD CONSTRAINT `id_Categorie` FOREIGN KEY (`id_Categorie`) REFERENCES `categorie` (`id_Categorie`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
