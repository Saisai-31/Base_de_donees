-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 10 oct. 2023 à 14:01
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `journal`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `id_Article` int NOT NULL AUTO_INCREMENT,
  `Nom de l'article` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `id_Sujet` int NOT NULL,
  `id_Journaliste` int NOT NULL,
  PRIMARY KEY (`id_Article`),
  KEY `id_Sujet` (`id_Sujet`),
  KEY `id_Journaliste` (`id_Journaliste`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_Article`, `Nom de l'article`, `id_Sujet`, `id_Journaliste`) VALUES
(11, 'La Russie interroge ', 12, 8),
(12, 'LeBron James toujours aussi solide', 11, 3),
(13, 'La révolution Tesla', 15, 3);

-- --------------------------------------------------------

--
-- Structure de la table `a_travailler_pour`
--

DROP TABLE IF EXISTS `a_travailler_pour`;
CREATE TABLE IF NOT EXISTS `a_travailler_pour` (
  `id_Journaliste` int NOT NULL,
  `id_Journal` int NOT NULL,
  PRIMARY KEY (`id_Journaliste`,`id_Journal`),
  KEY `id_Journaliste` (`id_Journaliste`,`id_Journal`),
  KEY `journal` (`id_Journal`),
  KEY `id_Journaliste_2` (`id_Journaliste`,`id_Journal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `a_travailler_pour`
--

INSERT INTO `a_travailler_pour` (`id_Journaliste`, `id_Journal`) VALUES
(9, 11),
(10, 12),
(7, 13);

-- --------------------------------------------------------

--
-- Structure de la table `interview`
--

DROP TABLE IF EXISTS `interview`;
CREATE TABLE IF NOT EXISTS `interview` (
  `id_Journaliste` int NOT NULL AUTO_INCREMENT,
  `id_Personnalite` int NOT NULL,
  PRIMARY KEY (`id_Journaliste`,`id_Personnalite`),
  KEY `id_Journaliste` (`id_Journaliste`,`id_Personnalite`),
  KEY `personnalite` (`id_Personnalite`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `interview`
--

INSERT INTO `interview` (`id_Journaliste`, `id_Personnalite`) VALUES
(4, 1),
(9, 3),
(5, 5);

-- --------------------------------------------------------

--
-- Structure de la table `journal`
--

DROP TABLE IF EXISTS `journal`;
CREATE TABLE IF NOT EXISTS `journal` (
  `id_Journal` int NOT NULL AUTO_INCREMENT,
  `Adresse` varchar(50) DEFAULT NULL,
  `Nom du Journal` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id_Journal`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `journal`
--

INSERT INTO `journal` (`id_Journal`, `Adresse`, `Nom du Journal`) VALUES
(11, 'Toulouse', 'La dépêche du Midi'),
(12, 'Paris', 'L\'équipe'),
(13, 'Paris', 'L\'humanité');

-- --------------------------------------------------------

--
-- Structure de la table `journaliste`
--

DROP TABLE IF EXISTS `journaliste`;
CREATE TABLE IF NOT EXISTS `journaliste` (
  `id_Journaliste` int NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) DEFAULT NULL,
  `Date_de_Naissance` date DEFAULT NULL,
  PRIMARY KEY (`id_Journaliste`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `journaliste`
--

INSERT INTO `journaliste` (`id_Journaliste`, `Nom`, `Date_de_Naissance`) VALUES
(1, 'Vachar', '1978-10-11'),
(2, 'Youcef', '0000-00-00'),
(3, 'Lafreitax', '1970-10-04'),
(4, 'Monsour', '1965-09-11'),
(5, 'Yallah', '1962-10-05'),
(6, 'Ballant', '1976-10-27'),
(7, 'Jambon', '1975-10-18'),
(8, 'Choucroutte', '1986-06-21'),
(9, 'Jaillard', '1983-01-12'),
(10, 'Djebali', '1971-05-14');

-- --------------------------------------------------------

--
-- Structure de la table `numero`
--

DROP TABLE IF EXISTS `numero`;
CREATE TABLE IF NOT EXISTS `numero` (
  `id_Numero` int NOT NULL AUTO_INCREMENT,
  `Dates` date DEFAULT NULL,
  `id_Journal` int NOT NULL,
  PRIMARY KEY (`id_Numero`),
  KEY `id_Journal` (`id_Journal`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `numero`
--

INSERT INTO `numero` (`id_Numero`, `Dates`, `id_Journal`) VALUES
(11, '2023-10-03', 12),
(12, '2023-10-04', 11),
(13, '2023-10-04', 13);

-- --------------------------------------------------------

--
-- Structure de la table `parait_dans`
--

DROP TABLE IF EXISTS `parait_dans`;
CREATE TABLE IF NOT EXISTS `parait_dans` (
  `id_Article` int NOT NULL,
  `id_Numero` int NOT NULL,
  PRIMARY KEY (`id_Article`,`id_Numero`),
  KEY `numero` (`id_Numero`),
  KEY `id_Article` (`id_Article`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `parait_dans`
--

INSERT INTO `parait_dans` (`id_Article`, `id_Numero`) VALUES
(11, 11),
(13, 12),
(12, 13);

-- --------------------------------------------------------

--
-- Structure de la table `personnalite`
--

DROP TABLE IF EXISTS `personnalite`;
CREATE TABLE IF NOT EXISTS `personnalite` (
  `id_Personnalite` int NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) DEFAULT NULL,
  `Prenom` varchar(50) DEFAULT NULL,
  `Nation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Personnalite`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `personnalite`
--

INSERT INTO `personnalite` (`id_Personnalite`, `Nom`, `Prenom`, `Nation`) VALUES
(1, 'Mbappe', 'Killian', 'France'),
(2, 'LeBron', 'James', 'Etats-Unis'),
(3, 'Poutine', 'Vladimir', 'Russie'),
(4, 'Roussel', 'Fabien', 'France'),
(5, 'Musk', 'Elon', 'Etats-Unis'),
(6, 'Ocon', 'Esteban', 'France'),
(7, 'Mola', 'Ugo', 'France'),
(8, 'Giustina', 'Gianfranco', 'Italie'),
(9, 'Grouard', 'Serge', 'France'),
(10, 'Sharif', 'Omar', 'France');

-- --------------------------------------------------------

--
-- Structure de la table `sujet`
--

DROP TABLE IF EXISTS `sujet`;
CREATE TABLE IF NOT EXISTS `sujet` (
  `id_Sujet` int NOT NULL AUTO_INCREMENT,
  `Libelle` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Sujet`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `sujet`
--

INSERT INTO `sujet` (`id_Sujet`, `Libelle`) VALUES
(11, 'Sport'),
(12, 'Géo-politique'),
(13, 'Information locale'),
(14, 'Information nationale'),
(15, 'Loisir');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `journalisteart` FOREIGN KEY (`id_Journaliste`) REFERENCES `journaliste` (`id_Journaliste`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sujet` FOREIGN KEY (`id_Sujet`) REFERENCES `sujet` (`id_Sujet`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Contraintes pour la table `a_travailler_pour`
--
ALTER TABLE `a_travailler_pour`
  ADD CONSTRAINT `journal` FOREIGN KEY (`id_Journal`) REFERENCES `journal` (`id_Journal`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `journalisteatp` FOREIGN KEY (`id_Journaliste`) REFERENCES `journaliste` (`id_Journaliste`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `interview`
--
ALTER TABLE `interview`
  ADD CONSTRAINT `journaliste` FOREIGN KEY (`id_Journaliste`) REFERENCES `journaliste` (`id_Journaliste`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `personnalite` FOREIGN KEY (`id_Personnalite`) REFERENCES `personnalite` (`id_Personnalite`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `numero`
--
ALTER TABLE `numero`
  ADD CONSTRAINT `journal2` FOREIGN KEY (`id_Journal`) REFERENCES `journal` (`id_Journal`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `parait_dans`
--
ALTER TABLE `parait_dans`
  ADD CONSTRAINT `article2` FOREIGN KEY (`id_Article`) REFERENCES `article` (`id_Article`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `numero` FOREIGN KEY (`id_Numero`) REFERENCES `numero` (`id_Numero`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
