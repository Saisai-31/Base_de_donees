-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 10 oct. 2023 à 14:01
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tournoi`
--

-- --------------------------------------------------------

--
-- Structure de la table `gagne`
--

DROP TABLE IF EXISTS `gagne`;
CREATE TABLE IF NOT EXISTS `gagne` (
  `id_Joueur` int NOT NULL,
  `id_Game` int NOT NULL,
  `Score` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Joueur`,`id_Game`),
  KEY `id_Joueur` (`id_Joueur`,`id_Game`),
  KEY `game` (`id_Game`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `game`
--

DROP TABLE IF EXISTS `game`;
CREATE TABLE IF NOT EXISTS `game` (
  `id_Game` int NOT NULL AUTO_INCREMENT,
  `Numero_du_match` int DEFAULT NULL,
  `Horaire` time DEFAULT NULL,
  PRIMARY KEY (`id_Game`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `game`
--

INSERT INTO `game` (`id_Game`, `Numero_du_match`, `Horaire`) VALUES
(11, 1, '09:49:41'),
(12, 2, '10:49:41'),
(13, 3, '11:50:55'),
(14, 4, '12:51:06'),
(15, 5, '13:28:42');

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

DROP TABLE IF EXISTS `joueur`;
CREATE TABLE IF NOT EXISTS `joueur` (
  `id_Joueur` int NOT NULL AUTO_INCREMENT,
  `Numero_de_carte` int DEFAULT NULL,
  `Nom` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Joueur`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `joueur`
--

INSERT INTO `joueur` (`id_Joueur`, `Numero_de_carte`, `Nom`) VALUES
(11, 120, 'Lola'),
(12, 122, 'Saisai'),
(13, 123, 'Poulard'),
(14, 124, 'Yallah');

-- --------------------------------------------------------

--
-- Structure de la table `participe`
--

DROP TABLE IF EXISTS `participe`;
CREATE TABLE IF NOT EXISTS `participe` (
  `id_Joueur` int NOT NULL,
  `id_Game` int NOT NULL,
  PRIMARY KEY (`id_Joueur`,`id_Game`),
  KEY `id_Joueur` (`id_Joueur`,`id_Game`),
  KEY `gamep` (`id_Game`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `se_joue_sur`
--

DROP TABLE IF EXISTS `se_joue_sur`;
CREATE TABLE IF NOT EXISTS `se_joue_sur` (
  `id_Game` int NOT NULL,
  `id_Terrain` int NOT NULL,
  PRIMARY KEY (`id_Game`,`id_Terrain`),
  KEY `id_Game` (`id_Game`,`id_Terrain`),
  KEY `terrain` (`id_Terrain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `terrain`
--

DROP TABLE IF EXISTS `terrain`;
CREATE TABLE IF NOT EXISTS `terrain` (
  `id_Terrain` int NOT NULL AUTO_INCREMENT,
  `Numero_de_terrain` int DEFAULT NULL,
  `Surface` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_Terrain`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `terrain`
--

INSERT INTO `terrain` (`id_Terrain`, `Numero_de_terrain`, `Surface`) VALUES
(1, 1, 'Terre battue'),
(2, 2, 'Terre battue'),
(3, 3, 'Terre battue'),
(4, 4, 'Terre battue'),
(5, 5, 'Gazon synthétique'),
(6, 6, 'Gazon synthétique'),
(7, 7, 'Gazon synthétique'),
(8, 8, ' Dur asphalte'),
(9, 9, ' Dur asphalte'),
(10, 10, ' Dur asphalte');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `gagne`
--
ALTER TABLE `gagne`
  ADD CONSTRAINT `game` FOREIGN KEY (`id_Game`) REFERENCES `game` (`id_Game`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `joueur` FOREIGN KEY (`id_Joueur`) REFERENCES `joueur` (`id_Joueur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `participe`
--
ALTER TABLE `participe`
  ADD CONSTRAINT `gamep` FOREIGN KEY (`id_Game`) REFERENCES `game` (`id_Game`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `joueurj` FOREIGN KEY (`id_Joueur`) REFERENCES `joueur` (`id_Joueur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `se_joue_sur`
--
ALTER TABLE `se_joue_sur`
  ADD CONSTRAINT `gamesjs` FOREIGN KEY (`id_Game`) REFERENCES `game` (`id_Game`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `terrain` FOREIGN KEY (`id_Terrain`) REFERENCES `terrain` (`id_Terrain`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
